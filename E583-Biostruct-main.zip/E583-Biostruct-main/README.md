# Biostruct Africa Workshop Sankey

This project generates an **interactive Sankey diagram** from Biostruct Africa workshop application data.

The diagram is exported as a **self-contained HTML file** with no backend dependency – you can open it in any modern browser and share it as-is.

---

## Features

- **First layer locked to `Workshop`**  
  Always shows workshop location (e.g. Kenya, Cameroon, Mali) as the left-most layer.

- **Configurable layers via dropdowns**  
  Remaining layers (e.g. Admission Outcome, Gender, Status, Country of Affiliation, Field of Research, Region, etc.) are selectable from dropdowns.  
  Each attribute can appear **only once** – once used in one layer it is removed from the others.

- **Client-side only**  
  All interactivity is driven by embedded JavaScript + Plotly. No server or API is required.

- **Color-blind friendly palette**  
  Nodes get high-contrast, Okabe–Ito-inspired colors per layer.

- **Hover interactions**
  - Hovering a node:
    - Highlights that node and all connected links.
    - Shows a custom tooltip summarizing the **distribution of other attributes** for only that node, in **percentages**.
  - Hovering a link:
    - Shows a small label like `Kenya → Rejected: 92`.

- **Old and new CSV schema support**
  - Works with older datasets containing columns like:
    - `Evaluation`, `Scientific_Discipline`, `Primary_ institutional_affiliation`, `region`, etc.
  - Works with the newer schema:
    - `Admission Outcome`, `Field of Research`, `Country of Affiliation`, `Region`, etc.
  - For old data, it automatically:
    - Derives `subregion` from `region` where applicable.
    - Creates a shortened `Primary_institution_short` field from `Primary_ institutional_affiliation`.

---

## Installation

### Prerequisites
- Python 3.7 or higher
- pip (Python package installer)

### Install Dependencies

**Option 1: Install directly (recommended for quick setup)**

```bash
pip install -r requirements.txt
```

Or if you're using Python 3 specifically:
```bash
pip3 install -r requirements.txt
```

**Note:** The script only requires `pandas` as an external dependency. All other modules (`json`, `os`, `sys`, `textwrap`) are part of Python's standard library. The Plotly visualization library is loaded from a CDN in the generated HTML, so it doesn't need to be installed as a Python package.

## Usage

### Running the Script

After installing dependencies, navigate to the `BioStruct_Africa_Final_Visualization` directory and run the script:

```bash
cd BioStruct_Africa_Final_Visualization
python create_sankey.py <input_csv> <output_html>
```

**Arguments:**
- `input_csv`: Name of the input CSV file (must be in the `processed_data/` directory)
- `output_html`: Name of the output HTML file (must end with `.html`, will be saved in `processed_data/` directory)

**Example:**
```bash
cd BioStruct_Africa_Final_Visualization
python create_sankey.py cleansed_biostruct_data_v4_comm_kcc.csv sankey_biostruct_workshop.html
```

The script will:
1. Load the CSV from `BioStruct_Africa_Final_Visualization/processed_data/<input_csv>`
2. Generate an interactive Sankey diagram
3. Save the HTML file to `BioStruct_Africa_Final_Visualization/processed_data/<output_html>`

You can then open the generated HTML file in any modern web browser to view and interact with the Sankey diagram.

## Project Structure

Typical layout:

```text
.
├── BioStruct_Africa_Final_Visualization/
│   ├── create_sankey.py          # Main script
│   └── processed_data/
│       ├── cleansed_biostruct_data_v4_comm_kcc.csv     # Your cleaned input datasets
│       └── sankey_biostruct_workshop.html              # Generated visualizations (output)
├── eda_and_preliminary_analysis/
│   ├── raw_data/                 # Raw data files
│   ├── processed_data/           # Processed reference data
│   └── transformation_and_visualization_scripts/  # Data cleaning notebooks
├── requirements.txt              # Python dependencies
└── README.md

## Code files at a glance

- `BioStruct_Africa_Final_Visualization/create_sankey.py`  
  Main script: loads a cleaned CSV, embeds it into a standalone Plotly Sankey app, and writes `processed_data/sankey_biostruct_workshop.html`.

- `eda_and_preliminary_analysis/transformation_and_visualization_scripts/clean_raw_to_processed.ipynb`  
  Cleans reference data in `raw_data/` (UNSD Methodology and ROR). Normalizes column names, trims/uppercases codes, coalesces subregion info, and saves reusable lookups to `processed_data/unsd_methodology_clean.csv` and `processed_data/ror_data_clean.csv`.

- `eda_and_preliminary_analysis/transformation_and_visualization_scripts/data_cleansing_and_eda.ipynb`  
  First-pass cleaning of the workshop application Excel (`raw_data/20251024_raw data BioStruct_map client project_final.xlsx`): normalizes text fields, maps blanks/NA-like tokens to `unknown`, and trims institution names.

- `eda_and_preliminary_analysis/transformation_and_visualization_scripts/data_cleansing_and_eda_v2.ipynb`  
  Iteration on the initial cleaning with the same source file, tighter normalization to `Unknown`, and removal of the `Institutional_ID` column.

- `eda_and_preliminary_analysis/transformation_and_visualization_scripts/data_cleansing_and_eda_v3.ipynb`  
  Refactored, end-to-end pipeline: imports UNSD/ROR reference tables, standardizes country and institution names, applies the OECD discipline mapping, and exports `processed_data/cleansed_biostruct_data_v3.csv`. Use this as the current single-pass cleaning notebook.